export const environment = {
  production: false,
  apiUrl: 'https://warm-mesa-88190.herokuapp.com/api/',
};
